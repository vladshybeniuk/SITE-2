import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { DollarSign, Sparkles, Users, Zap, Headphones, Diamond, Banknote, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

const benefits = [
  { icon: DollarSign, text: "Fair payment" },
  { icon: Sparkles, text: "Creative freedom" },
  { icon: Users, text: "Non-exclusive partnerships" },
  { icon: Zap, text: "Transparency and speed" },
  { icon: Headphones, text: "Personalized support" },
];

const offerings = [
  "Expert guidance and negotiation support",
  "Dedicated team for every campaign",
  "Average payout time: 14 days",
];

const promises = [
  { icon: Diamond, text: "100% non-exclusive — your content, your rules" },
  { icon: Banknote, text: "Direct payment within 30 days after completion" },
  { icon: Heart, text: "24/7 support from your campaign manager" },
];

export default function ForCreatorsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section 
      ref={ref} 
      className="py-24 md:py-32 bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-primary/10 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-purple-500/5 via-transparent to-transparent"></div>
      
      <div className="container mx-auto px-8 md:px-12 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            Join the Aura Creator Network
          </h2>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-3xl mx-auto">
            Collaborate with top brands. Get paid what you deserve.
          </p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-lg text-center max-w-4xl mx-auto mb-16 leading-relaxed"
        >
          At Aura Agency, we connect creators with premium brands that value authenticity, creativity, and real influence.
        </motion.p>

        <div className="grid md:grid-cols-5 gap-6 max-w-5xl mx-auto mb-16">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={benefit.text}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 + index * 0.1 }}
                className="flex flex-col items-center text-center p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover-elevate"
                data-testid={`benefit-${index}`}
              >
                <Icon className="w-10 h-10 mb-4 text-primary" />
                <p className="text-sm font-medium">{benefit.text}</p>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="max-w-3xl mx-auto mb-12"
        >
          <h3 className="text-2xl md:text-3xl font-semibold mb-6 text-center">What We Offer</h3>
          <ul className="space-y-3">
            {offerings.map((offering, index) => (
              <li key={index} className="flex items-center gap-3 text-lg">
                <div className="w-2 h-2 rounded-full bg-primary"></div>
                {offering}
              </li>
            ))}
          </ul>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <h3 className="text-2xl md:text-3xl font-semibold mb-8 text-center">Our Promise</h3>
          <div className="grid md:grid-cols-3 gap-6">
            {promises.map((promise, index) => {
              const Icon = promise.icon;
              return (
                <div
                  key={index}
                  className="p-6 rounded-2xl bg-card/70 backdrop-blur border border-border/50 hover-elevate"
                  data-testid={`promise-${index}`}
                >
                  <Icon className="w-8 h-8 mb-4 text-primary" />
                  <p className="leading-relaxed">{promise.text}</p>
                </div>
              );
            })}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 1 }}
          className="text-center mt-12"
        >
          <Button
            size="lg"
            className="rounded-full px-10 py-7 text-lg font-semibold tracking-wide bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            data-testid="button-join-network"
          >
            Apply to Join
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
