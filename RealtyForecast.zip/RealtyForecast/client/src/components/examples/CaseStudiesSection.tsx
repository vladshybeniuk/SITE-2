import CaseStudiesSection from '../CaseStudiesSection';

export default function CaseStudiesSectionExample() {
  return <CaseStudiesSection />;
}
