import ForCreatorsSection from '../ForCreatorsSection';

export default function ForCreatorsSectionExample() {
  return <ForCreatorsSection />;
}
