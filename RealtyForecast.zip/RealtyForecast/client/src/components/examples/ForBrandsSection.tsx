import ForBrandsSection from '../ForBrandsSection';

export default function ForBrandsSectionExample() {
  return <ForBrandsSection />;
}
