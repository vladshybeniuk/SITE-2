import ServicesSection from '../ServicesSection';

export default function ServicesSectionExample() {
  return <ServicesSection />;
}
