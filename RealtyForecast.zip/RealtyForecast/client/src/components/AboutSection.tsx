import { motion, useInView } from "framer-motion";
import { useRef } from "react";

export default function AboutSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-24 md:py-32 bg-muted/10">
      <div className="container mx-auto px-8 md:px-12">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl md:text-5xl font-semibold tracking-tight mb-6">
              About Aura
            </h2>
            <div className="space-y-4 text-lg leading-relaxed text-foreground/80">
              <p>
                We're a global influencer marketing agency that bridges the gap between visionary brands and culture-defining creators.
              </p>
              <p>
                Our approach is rooted in authenticity, data-driven strategy, and a deep understanding of what moves audiences. From campaign ideation to execution, we craft collaborations that don't just reach—they resonate.
              </p>
              <p>
                With a network spanning continents and platforms, we turn creative vision into measurable impact.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="/images/about-aura.jpg" 
                alt="Creative professional working at Aura Agency" 
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/10 to-transparent"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
