import { motion, useInView } from "framer-motion";
import { useRef, useState } from "react";

const caseStudies = [
  {
    id: 1,
    brand: "LuxeBeauty",
    category: "Beauty & Wellness",
    description: "50M+ impressions across TikTok and Instagram",
    gradient: "from-pink-500/20 to-purple-500/20",
  },
  {
    id: 2,
    brand: "TechFlow",
    category: "Consumer Tech",
    description: "300% ROI with micro-influencer strategy",
    gradient: "from-blue-500/20 to-cyan-500/20",
  },
  {
    id: 3,
    brand: "UrbanStyle",
    category: "Fashion & Lifestyle",
    description: "Viral campaign reaching 100M+ users",
    gradient: "from-orange-500/20 to-red-500/20",
  },
  {
    id: 4,
    brand: "GreenEarth",
    category: "Sustainability",
    description: "Award-winning environmental advocacy campaign",
    gradient: "from-green-500/20 to-emerald-500/20",
  },
  {
    id: 5,
    brand: "FitLife",
    category: "Health & Fitness",
    description: "Community-driven transformation stories",
    gradient: "from-violet-500/20 to-fuchsia-500/20",
  },
  {
    id: 6,
    brand: "FoodieHub",
    category: "Food & Beverage",
    description: "Cross-platform culinary creator network",
    gradient: "from-yellow-500/20 to-amber-500/20",
  },
];

export default function CaseStudiesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [hoveredId, setHoveredId] = useState<number | null>(null);

  return (
    <section ref={ref} className="py-24 md:py-32 bg-background">
      <div className="container mx-auto px-8 md:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-semibold tracking-tight mb-4">
            Success stories
          </h2>
          <p className="text-xl text-muted-foreground">
            Campaigns that moved the needle
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl mx-auto">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.id}
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              onMouseEnter={() => setHoveredId(study.id)}
              onMouseLeave={() => setHoveredId(null)}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card aspect-[4/3] cursor-pointer transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
              data-testid={`card-case-study-${study.id}`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${study.gradient} transition-opacity duration-300 ${hoveredId === study.id ? 'opacity-100' : 'opacity-50'}`}></div>
              
              <div className="relative h-full p-8 flex flex-col justify-end">
                <motion.div
                  initial={false}
                  animate={{ y: hoveredId === study.id ? -10 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <p className="text-sm text-muted-foreground mb-2">{study.category}</p>
                  <h3 className="text-3xl font-bold mb-2 tracking-tight">{study.brand}</h3>
                  <p className="text-sm text-foreground/80">{study.description}</p>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
