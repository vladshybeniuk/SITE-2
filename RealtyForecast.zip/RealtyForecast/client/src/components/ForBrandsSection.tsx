import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Search, Target, Rocket, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";

const stages = [
  {
    number: "01",
    icon: Search,
    title: "Discovery",
    description: "We analyze your brand, audience, and market position to craft strategy.",
  },
  {
    number: "02",
    icon: Target,
    title: "Matching",
    description: "We identify creators who align with your message and values.",
  },
  {
    number: "03",
    icon: Rocket,
    title: "Activation",
    description: "We coordinate content creation, launch timelines, and delivery.",
  },
  {
    number: "04",
    icon: TrendingUp,
    title: "Optimization",
    description: "We measure, analyze, and scale what works to maximize ROI.",
  },
];

export default function ForBrandsSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section 
      ref={ref} 
      className="py-24 md:py-32 bg-gradient-to-br from-blue-500/10 via-cyan-500/10 to-primary/10 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-blue-500/5 via-transparent to-transparent"></div>
      
      <div className="container mx-auto px-8 md:px-12 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-6xl font-bold tracking-tight mb-4">
            How it works
          </h2>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-lg text-center max-w-4xl mx-auto mb-8 leading-relaxed"
        >
          Launch powerful influencer campaigns with Aura Agency. We match your brand with the right creators and manage end-to-end — from strategy to reporting — powered by real-time data, creative insights, and a top-tier network across platforms.
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="text-xl md:text-2xl font-semibold text-center max-w-3xl mx-auto mb-16 bg-gradient-to-r from-primary to-blue-600 bg-clip-text text-transparent"
        >
          Our mission is to turn attention into results — and make your brand impossible to ignore.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-5xl mx-auto mb-16 p-8 md:p-12 rounded-3xl bg-card/70 backdrop-blur border border-border/50 shadow-xl"
        >
          <div className="flex items-start gap-4 mb-4">
            <div className="text-6xl">"</div>
            <div>
              <p className="text-lg md:text-xl italic mb-6 leading-relaxed">
                They understood our vision instantly. Every campaign felt authentic and aligned with our goals — we saw measurable results from day one.
              </p>
              <p className="text-sm md:text-base font-semibold">— Sophia Davis, Marketing Team Lead</p>
            </div>
          </div>
        </motion.div>

        <div className="grid md:grid-cols-4 gap-6 max-w-7xl mx-auto mb-16">
          {stages.map((stage, index) => {
            const Icon = stage.icon;
            return (
              <motion.div
                key={stage.number}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
                className="relative p-6 rounded-2xl bg-card/50 backdrop-blur-sm border border-border/50 hover-elevate group"
                data-testid={`stage-${index}`}
              >
                <div className="text-5xl font-bold text-primary/20 mb-4">{stage.number}</div>
                <Icon className="w-10 h-10 mb-4 text-primary" />
                <h3 className="text-xl font-semibold mb-3">{stage.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {stage.description}
                </p>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.9 }}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center"
        >
          <Button
            size="lg"
            className="rounded-full px-10 py-7 text-lg font-semibold tracking-wide bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-500 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            data-testid="button-start-campaign"
          >
            Start a Campaign
          </Button>
          <Button
            size="lg"
            className="rounded-full px-10 py-7 text-lg font-semibold tracking-wide bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300"
            data-testid="button-explore-services"
          >
            Explore Services
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
