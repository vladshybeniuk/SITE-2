import { motion, useInView } from "framer-motion";
import { useRef } from "react";
import { Sparkles, Users, Lightbulb, Handshake } from "lucide-react";

const services = [
  {
    icon: Sparkles,
    title: "Influencer Campaigns",
    description: "Strategic creator partnerships that amplify your brand message across all platforms.",
  },
  {
    icon: Users,
    title: "Talent Management",
    description: "End-to-end representation for creators, from contracts to brand collaborations.",
  },
  {
    icon: Lightbulb,
    title: "Creative Strategy",
    description: "Data-driven campaigns designed to maximize engagement and conversion.",
  },
  {
    icon: Handshake,
    title: "Brand Partnerships",
    description: "Authentic collaborations that align brand values with creator audiences.",
  },
];

export default function ServicesSection() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-24 md:py-32 bg-card/50">
      <div className="container mx-auto px-8 md:px-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-semibold tracking-tight mb-4">
            What we do
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="group p-8 rounded-2xl border border-border bg-card hover-elevate active-elevate-2 transition-all duration-300 hover:scale-[1.02] hover:shadow-lg"
                data-testid={`card-service-${index}`}
              >
                <Icon className="w-12 h-12 mb-6 text-primary stroke-[1.5]" />
                <h3 className="text-2xl font-semibold mb-3 tracking-tight">
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
