import { useEffect, useState } from "react";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import CaseStudiesSection from "@/components/CaseStudiesSection";
import ForCreatorsSection from "@/components/ForCreatorsSection";
import ForBrandsSection from "@/components/ForBrandsSection";
import ContactSection from "@/components/ContactSection";

export default function Home() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToContact = () => {
    document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" });
  };

  const progressiveBackground = () => {
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    const scrollProgress = Math.min(scrollY / maxScroll, 1);
    
    if (scrollProgress < 0.2) {
      return "bg-background";
    } else if (scrollProgress < 0.5) {
      return "bg-muted/10";
    } else if (scrollProgress < 0.8) {
      return "bg-card/20";
    } else {
      return "bg-muted/20";
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-1000 ${progressiveBackground()}`}>
      <HeroSection onCtaClick={scrollToContact} />
      <AboutSection />
      <ServicesSection />
      <CaseStudiesSection />
      <ForCreatorsSection />
      <ForBrandsSection />
      <ContactSection />
      
      <footer className="py-8 border-t border-border bg-background">
        <div className="container mx-auto px-8 md:px-12 text-center text-sm text-muted-foreground">
          <p>© 2024 Aura Agency. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
