# Aura Agency - Influencer Marketing Platform

## Overview

Aura Agency is a next-generation influencer marketing platform that connects brands with creators. The application features a premium, modern landing page with smooth animations, progressive background transitions, and dedicated sections for both brands and creators. Built with React, TypeScript, and a focus on high-end visual design inspired by minimalist luxury aesthetics.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens
- **Animations**: Framer Motion for scroll-based and entrance animations
- **State Management**: TanStack Query (React Query) for server state

**Design System:**
- Custom color palette with progressive theme transitions (light to dark as user scrolls)
- Inter font family for modern geometric typography
- Comprehensive spacing system using Tailwind units (4, 8, 12, 16, 20, 24, 32)
- Modular component architecture with reusable UI primitives
- Responsive design with mobile-first approach

**Key UI Patterns:**
- Scroll-triggered animations using Intersection Observer (via Framer Motion's useInView)
- Gradient backgrounds that transition based on scroll position
- Glass morphism effects on buttons with hover animations
- Section-based layout with dedicated components for Hero, About, Services, Case Studies, For Creators, For Brands, and Contact

### Backend Architecture

**Server Framework:**
- Express.js with TypeScript
- Custom middleware for request logging and error handling
- Vite integration for development with HMR (Hot Module Replacement)
- Static file serving in production

**Data Layer:**
- Drizzle ORM configured for PostgreSQL
- Schema-first approach with TypeScript type inference
- Zod validation integrated via drizzle-zod
- In-memory storage implementation (MemStorage) as fallback/development option
- Database migrations managed through Drizzle Kit

**Current Schema:**
- Users table with username/password authentication structure
- UUID-based primary keys using PostgreSQL's gen_random_uuid()
- Prepared for expansion with influencer, brand, and campaign entities

**API Design:**
- RESTful endpoints prefixed with /api
- JSON request/response format
- Session-based authentication ready (connect-pg-simple for session storage)
- Credential-based fetch requests with cookie support

### Build & Deployment

**Development:**
- Vite dev server with React Fast Refresh
- TypeScript compilation without emit (type checking only)
- Path aliases for clean imports (@/, @shared/, @assets/)
- Source maps enabled for debugging

**Production:**
- Vite builds optimized frontend bundle to dist/public
- esbuild bundles server code to dist/ (ESM format)
- Environment-based configuration (NODE_ENV)
- Server runs on Node.js with compiled JavaScript

### Project Structure

```
/client          # Frontend application
  /src
    /components  # React components (sections, UI primitives)
    /pages       # Route components
    /hooks       # Custom React hooks
    /lib         # Utilities (queryClient, utils)
  index.html     # Entry HTML
  
/server          # Backend application
  index.ts       # Express server setup
  routes.ts      # API route definitions
  storage.ts     # Data access layer
  vite.ts        # Vite integration
  
/shared          # Code shared between client/server
  schema.ts      # Database schema and types
  
/attached_assets # Design specifications and requirements
```

## External Dependencies

### UI & Design
- **Radix UI**: Headless UI primitives for accessibility (@radix-ui/* packages)
- **Shadcn/ui**: Pre-built component library configuration
- **Tailwind CSS**: Utility-first CSS framework with PostCSS
- **Framer Motion**: Animation library for scroll and entrance effects
- **Embla Carousel**: Touch-enabled carousel component
- **Lucide React**: Icon library

### State & Data Management
- **TanStack Query**: Server state management and caching
- **React Hook Form**: Form handling with validation
- **Zod**: Schema validation
- **@hookform/resolvers**: Zod integration for forms

### Backend & Database
- **Drizzle ORM**: TypeScript ORM for PostgreSQL
- **@neondatabase/serverless**: Neon PostgreSQL serverless driver
- **connect-pg-simple**: PostgreSQL session store for Express
- **Express**: Web application framework
- **Wouter**: Lightweight routing for React

### Development Tools
- **Vite**: Build tool and dev server
- **TypeScript**: Type safety across stack
- **ESBuild**: JavaScript bundler for server code
- **tsx**: TypeScript execution for development
- **@replit/vite-plugin-***: Replit-specific development plugins

### Potential Future Integrations
- Authentication provider (Auth0, Clerk, or custom JWT)
- File upload service (AWS S3, Cloudinary)
- Email service (SendGrid, Postmark)
- Analytics platform (Google Analytics, Mixpanel)
- Payment processing (Stripe)
- Social media APIs (Instagram, TikTok, YouTube)