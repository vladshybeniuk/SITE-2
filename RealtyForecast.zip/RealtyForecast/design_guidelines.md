# Aura Agency - Premium Design Guidelines

## Design Approach
**Reference-Based Design**: Inspired by Pulse Advertising's minimalist luxury aesthetic - clean layouts, high-end visual identity, elegant motion, and bold typography. Premium, futuristic feel with organic animations.

## Core Design Elements

### A. Color Palette
**Progressive Theme Transition** - Lighter tones at top, gradually darkening as user scrolls:

**Light Section (Hero/Top)**
- Background: 0 0% 98% (near white)
- Primary Text: 0 0% 10% (near black)
- Accent: 240 5% 65% (soft gray-blue)

**Mid Sections**
- Background: 0 0% 12% (dark charcoal)
- Primary Text: 0 0% 95% (off-white)
- Accent: Linear gradient subtle hints (220 70% 50% to 280 70% 50%)

**Dark Sections (Bottom)**
- Background: 0 0% 5% (deep black)
- Primary Text: 0 0% 98%
- Accent: 240 5% 30% (muted blue-gray)

### B. Typography
**Font Stack**: Inter or similar modern geometric sans-serif

**Hierarchy**:
- Hero Headline: text-6xl to text-8xl, font-bold, tracking-tight, leading-none
- Section Headlines: text-4xl to text-5xl, font-semibold, tracking-tight
- Subheadlines: text-xl to text-2xl, font-normal, tracking-wide
- Body: text-base to text-lg, font-normal, leading-relaxed
- CTA Buttons: text-lg, font-medium, tracking-wide

### C. Layout System
**Spacing**: Tailwind units of 4, 8, 12, 16, 20, 24, 32 (generous whitespace)
- Section padding: py-20 to py-32 (desktop), py-12 to py-16 (mobile)
- Container: max-w-7xl with px-8 to px-12
- Grid gaps: gap-8 to gap-12

## Section Specifications

### Hero Section (Full Viewport)
- Full-screen (min-h-screen) with dynamic gradient background or subtle video loop
- Centered content with max-w-5xl
- Headline: "A next-generation influencer marketing agency connecting brands with creators who move culture."
- Subheadline: "We craft authentic collaborations that inspire and convert."
- CTA: Large button "Let's collaborate" with smooth scroll to contact
- Fade-in animation on load (0.8s delay)

### About Aura
- Split layout: Text (60%) + Minimal visual/animation (40%)
- Text block: max-w-2xl, elegant paragraph spacing
- Parallax effect on visual element
- Fade-in on scroll trigger

### Services
- 2x2 grid on desktop, stack on mobile
- Services: Influencer Campaigns, Talent Management, Creative Strategy, Brand Partnerships
- Minimal icons (line-style)
- Card hover: Subtle scale (1.02) and shadow elevation
- Stagger fade-in animation

### Case Studies
- Grid layout (3 columns desktop, 1 mobile) or smooth carousel
- Image-first showcases with brand logos overlay
- Hover: Image zoom (1.05), overlay fade-in with project details
- Smooth transitions (300ms ease)

### Contact Section
- Centered layout, max-w-2xl
- Headline: "Ready to make your brand go viral?"
- Form fields: Name, Email, Message (textarea)
- Input styling: Transparent bg, bottom border only, focus state with accent color
- Social icons below (Instagram, LinkedIn, Email) with hover scale
- Send button: Full-width on mobile, auto on desktop

## Animation Principles
**Organic Motion - Never Flashy**:
- Fade-in on scroll: opacity 0→1, translateY 20px→0, duration 0.6s
- Parallax: Subtle depth (0.3-0.5 factor)
- Hover states: Scale 1.02-1.05, transition 300ms
- Smooth scroll behavior throughout
- Intersection Observer triggers at 10% viewport
- Stagger delays: 100-150ms between elements

## Images
**Hero Section**: Dynamic gradient background OR subtle looping video (abstract, ethereal visuals - flowing shapes or particle effects in brand colors)

**About Section**: Minimal abstract visual or animated graphic element representing creativity/connection

**Case Studies**: Brand collaboration showcase images (3-6 examples with logos/campaign visuals)

**No large hero image** - instead using dynamic gradient/video for premium feel

## Component Library
- Buttons: Rounded (rounded-full), generous padding (px-8 py-4), backdrop-blur-md on glass effect variants
- Form inputs: Minimal border-bottom style, floating labels
- Cards: Subtle border (border-gray-800), hover shadow-xl, rounded-2xl
- Icons: Line-style, stroke-width-1.5, size-8 to size-12

## Responsive Behavior
- Sections: Full-width, controlled max-width containers
- Typography: Scale down 1-2 sizes on mobile
- Grid: 3→2→1 column collapse
- Spacing: Reduce by ~40% on mobile
- Animations: Reduced motion respected, gentler on mobile